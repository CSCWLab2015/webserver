var express     = require("express"),
    bodyParser  = require("body-parser"),
    http        = require("http"),
    letters     = require("./json/letters.json"),
    arstatus     = require("./json/status.json");

var STATUS = {
    800:  {
            info: "status",
            message: "Status"
          },
    801: {
          info: "waiting",
          message: "Job Submitted"
          },
    802: {
          info: "waiting",
          message: "Job Started"
          },
    803: {
          info: "waiting",
          message: "Job Done"
          },
    810: {
          info: "printing",
          message: "Printing"
          },
    820: {
          info: "waiting",
          message: "Moving to printer"
          },
    821: {
          info: "waiting",
          message: "Moving to delivery warehouse"
          },
    830: {
          info: "waiting",
          message: "Loading"
          },
    831: {
          info: "waiting",
          message: "Unloading"
          },
    901: {
          info: "error",
          message: "Bluetooth communication error"
          },
    902: {
          info: "error",
          message: "Job could not be started"
          },
    910: {
          info: "error",
          message: "Brick is not available in the ware house to be used in printing"
          },
    911: {
          info: "error",
          message: "Brick is not picked up by the printer head from the bricks warehouse"
          },
    912: {
          info: "error",
          message: "Brick is not plugged to the plate (still in the head)."
          },
    913: {
          info: "error",
          message: "Brick is not plugged to the correct position on the plate"
          }
};

var arResponse, RESPONSE, LETTER ="";
var app = express();

var i =0;

arResponse = arstatus[i%29];

setInterval(function(){
  i++;
  arResponse = arstatus[i%29];
  }, 40000);


////////////////////////////
//
// Adding header of the API
//
////////////////////////////

app.use(function(req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  return next();
});
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 



////////////////////////////
//
// Express modules
//
////////////////////////////

app.get("/letters",function(req,res){
  res.send(letters);
});

app.get("/plates",function(req,res){
  var plateInfo = {"letter": LETTER};
  res.send(plateInfo);
});

app.get("/arstatus",function(req,res){

  res.send(arResponse);
});


app.listen(8080);
console.log("INFO: AR dummy server started")